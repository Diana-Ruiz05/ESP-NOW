#include "ultrasonic.h"

#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/portmacro.h>  
#include <esp_timer.h>
#include <driver/gpio.h>
#include "esp32/rom/ets_sys.h"

#define TRIGGER_LOW_DELAY   4
#define TRIGGER_HIGH_DELAY  10
#define PING_TIMEOUT        6000
#define ROUNDTRIP_M         171.5f    // Corregido: (343 m/s) / (2 * 1,000,000 μs/s)
#define ROUNDTRIP_CM        58.3f     // Corregido: (34300 cm/s) / (2 * 1,000,000 μs/s)
#define MIN_DELAY_BETWEEN_MEASUREMENTS  60000  // 60ms mínimo entre mediciones

// Límites de distancia típicos para sensores HC-SR04
#define MIN_DISTANCE_CM     2
#define MAX_DISTANCE_CM     400
#define MIN_DISTANCE_M      0.02f
#define MAX_DISTANCE_M      4.0f

// Variable estática para controlar el timing entre mediciones
static int64_t last_measurement_time = 0;

// Spinlock para secciones críticas
static portMUX_TYPE mux = portMUX_INITIALIZER_UNLOCKED;

#define PORT_ENTER_CRITICAL() portENTER_CRITICAL(&mux)
#define PORT_EXIT_CRITICAL()  portEXIT_CRITICAL(&mux)

#define timeout_expired(start, len) ((esp_timer_get_time() - (start)) >= (len))
#define CHECK_ARG(VAL) do { if (!(VAL)) return ESP_ERR_INVALID_ARG; } while (0)
#define CHECK(x) do { esp_err_t __; if ((__ = x) != ESP_OK) return __; } while (0)
#define RETURN_CRITICAL(RES) do { PORT_EXIT_CRITICAL(); return RES; } while(0)

esp_err_t ultrasonic_init(const ultrasonic_sensor_t *dev)
{
    CHECK_ARG(dev);

    CHECK(gpio_set_direction(dev->trigger_pin, GPIO_MODE_OUTPUT));
    CHECK(gpio_set_direction(dev->echo_pin, GPIO_MODE_INPUT));

    // Inicializar trigger en LOW
    CHECK(gpio_set_level(dev->trigger_pin, 0));
    
    // Inicializar el tiempo de la última medición
    last_measurement_time = 0;

    return ESP_OK;
}

esp_err_t ultrasonic_measure_raw(const ultrasonic_sensor_t *dev, uint32_t max_time_us, uint32_t *time_us)
{
    CHECK_ARG(dev && time_us);

    // Verificar delay mínimo entre mediciones
    int64_t current_time = esp_timer_get_time();
    if (last_measurement_time > 0 && 
        (current_time - last_measurement_time) < MIN_DELAY_BETWEEN_MEASUREMENTS) {
        vTaskDelay(pdMS_TO_TICKS(65)); // Esperar un poco más para estar seguro
    }

    PORT_ENTER_CRITICAL();

    // Ping: Low for 2..4 us, then high 10 us
    CHECK(gpio_set_level(dev->trigger_pin, 0));
    ets_delay_us(TRIGGER_LOW_DELAY);
    CHECK(gpio_set_level(dev->trigger_pin, 1));
    ets_delay_us(TRIGGER_HIGH_DELAY);
    CHECK(gpio_set_level(dev->trigger_pin, 0));

    // Verificar que el pin de echo no esté ya en HIGH (menos estricto)
    // Dar una pequeña oportunidad para que se estabilice
    ets_delay_us(2);
    
    // Wait for echo to go HIGH
    int64_t start = esp_timer_get_time();
    while (!gpio_get_level(dev->echo_pin))
    {
        if (timeout_expired(start, PING_TIMEOUT))
            RETURN_CRITICAL(ESP_ERR_ULTRASONIC_PING_TIMEOUT);
    }

    // Got echo, measuring duration
    int64_t echo_start = esp_timer_get_time();
    int64_t time = echo_start;
    while (gpio_get_level(dev->echo_pin))
    {
        time = esp_timer_get_time();
        if (timeout_expired(echo_start, max_time_us))
            RETURN_CRITICAL(ESP_ERR_ULTRASONIC_ECHO_TIMEOUT);
    }

    PORT_EXIT_CRITICAL();

    // Actualizar el tiempo de la última medición
    last_measurement_time = esp_timer_get_time();

    *time_us = time - echo_start;

    return ESP_OK;
}

esp_err_t ultrasonic_measure(const ultrasonic_sensor_t *dev, float max_distance, float *distance)
{
    CHECK_ARG(dev && distance);
    
    // Validar rango máximo
    if (max_distance > MAX_DISTANCE_M) {
        max_distance = MAX_DISTANCE_M;
    }

    uint32_t time_us;
    CHECK(ultrasonic_measure_raw(dev, max_distance * ROUNDTRIP_M, &time_us));
    
    *distance = time_us / ROUNDTRIP_M;
    
    // Validar rango de resultado
    if (*distance < MIN_DISTANCE_M || *distance > MAX_DISTANCE_M) {
        return ESP_ERR_ULTRASONIC_OUT_OF_RANGE;
    }

    return ESP_OK;
}

esp_err_t ultrasonic_measure_cm(const ultrasonic_sensor_t *dev, uint32_t max_distance, uint32_t *distance)
{
    CHECK_ARG(dev && distance);
    
    // Validar rango máximo
    if (max_distance > MAX_DISTANCE_CM) {
        max_distance = MAX_DISTANCE_CM;
    }

    uint32_t time_us;
    CHECK(ultrasonic_measure_raw(dev, max_distance * ROUNDTRIP_CM, &time_us));
    
    *distance = time_us / ROUNDTRIP_CM;
    
    // Validar rango de resultado
    if (*distance < MIN_DISTANCE_CM || *distance > MAX_DISTANCE_CM) {
        return ESP_ERR_ULTRASONIC_OUT_OF_RANGE;
    }

    return ESP_OK;
}

// Función adicional para obtener múltiples mediciones y promediarlas
esp_err_t ultrasonic_measure_average_cm(const ultrasonic_sensor_t *dev, uint32_t max_distance, 
                                       uint8_t samples, uint32_t *distance)
{
    CHECK_ARG(dev && distance && samples > 0);
    
    if (samples > 10) samples = 10; // Limitar a máximo 10 muestras
    
    uint32_t sum = 0;
    uint8_t valid_samples = 0;
    
    for (uint8_t i = 0; i < samples; i++) {
        uint32_t single_distance;
        esp_err_t err = ultrasonic_measure_cm(dev, max_distance, &single_distance);
        
        if (err == ESP_OK) {
            sum += single_distance;
            valid_samples++;
        }
        
        // Delay entre muestras si no es la última
        if (i < samples - 1) {
            vTaskDelay(pdMS_TO_TICKS(65));
        }
    }
    
    if (valid_samples == 0) {
        return ESP_ERR_ULTRASONIC_NO_VALID_SAMPLES;
    }
    
    *distance = sum / valid_samples;
    return ESP_OK;
}