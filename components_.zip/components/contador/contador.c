#include "contador.h"

volatile bool tiempo_1 = false;
volatile bool tiempo_2 = false;
volatile bool tiempo_3 = false;
volatile bool tiempo_4 = false;

// ⚡ Bandera global para saber si un timer está activo
bool timer_en_marcha[3] = {false, false, false}; // 0=semaforo,1=extremos,2=delay

void configurar_tiempo(gptimer_handle_t *gptimer, int Nsegundos, gptimer_alarm_cb_t callback) {
    gptimer_config_t config = {
        .clk_src = GPTIMER_CLK_SRC_DEFAULT,
        .direction = GPTIMER_COUNT_UP,
        .resolution_hz = 1000000,  // 1 MHz
    };

    gptimer_handle_t timer_temp;
    gptimer_new_timer(&config, &timer_temp);

    gptimer_alarm_config_t alarm_config = {
        .alarm_count = Nsegundos * 1000000ULL,
        .reload_count = 0,
        .flags.auto_reload_on_alarm = false,
    };
    gptimer_set_alarm_action(timer_temp, &alarm_config);

    gptimer_register_event_callbacks(timer_temp, &(gptimer_event_callbacks_t){
        .on_alarm = callback
    }, NULL);

    gptimer_enable(timer_temp);

    *gptimer = timer_temp;
}

void configurar_alarma(gptimer_handle_t gptimer, int Nsegundos) {
    gptimer_alarm_config_t alarm_config = {
        .alarm_count = Nsegundos * 1000000ULL,
        .reload_count = 0,
        .flags.auto_reload_on_alarm = false,
    };
    gptimer_set_alarm_action(gptimer, &alarm_config);
}

void iniciar_conteo(gptimer_handle_t *gptimer) {
    if (gptimer && *gptimer) {
        gptimer_start(*gptimer);
    }
}

void detener_conteo(gptimer_handle_t *gptimer) {
    if (gptimer && *gptimer) {
        // ⚠️ No se llama gptimer_stop si no fue iniciado (controlado por bandera en main)
        gptimer_stop(*gptimer);
    }
}
