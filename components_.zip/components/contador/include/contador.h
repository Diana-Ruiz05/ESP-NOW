#ifndef CONTADOR_H
#define CONTADOR_H

#include <stdint.h>
#include <stdio.h>
#include "esp_err.h"
#include "driver/gptimer.h"

extern volatile bool tiempo_1;
extern volatile bool tiempo_2;
extern volatile bool tiempo_3;
extern volatile bool tiempo_4;

void configurar_tiempo(gptimer_handle_t *gptimer, int Nsegundos, gptimer_alarm_cb_t callback);
void configurar_alarma(gptimer_handle_t gptimer, int Nsegundos);
void iniciar_conteo(gptimer_handle_t *gptimer);
void detener_conteo(gptimer_handle_t *gptimer);

#endif