#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "driver/gpio.h"
#include "esp_now.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include "ultrasonic.h"
#include "ssd1306.h"
#include "contador.h"

#define TRIGGER_PIN GPIO_NUM_18
#define ECHO_PIN GPIO_NUM_19
#define DETECTION_DISTANCE 12
static const char *TAG = "SEMAFORO";

// ==================== SEMÁFORO ====================
typedef struct {
    gpio_num_t amarillo;
    gpio_num_t verde;
    gpio_num_t rojo;
} semaforo_t;
typedef enum {
    ESTADO_NORMAL,
    PRIORIDAD1,
    PRIORIDAD2,
    SIN_CONEXION
} estado_t;

semaforo_t semaforo_uno = {
    .verde    = GPIO_NUM_5,
    .amarillo = GPIO_NUM_4,
    .rojo     = GPIO_NUM_2
};
ultrasonic_sensor_t sensor_ultrasonic = {
    .echo_pin = ECHO_PIN,
    .trigger_pin = TRIGGER_PIN,
};
// ==================== VARIABLES GLOBALES ====================
static uint8_t mac_peer[ESP_NOW_ETH_ALEN] = {0x6c, 0xc8, 0x40, 0x35, 0x68, 0x44};
char ultimo_mensaje[250] = {};
bool coneccion = false;
bool deteccion_local = true;
bool deteccion_remota = false;
volatile bool actividad_recibida = false;


SemaphoreHandle_t sem_mensaje_nuevo;
bool peer_agregado = false;
// ==================== WIFI Y ESP-NOW ====================
void init_wifi(void) {
    esp_err_t ret = nvs_flash_init();
    if(ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ESP_ERROR_CHECK(nvs_flash_init());
    }
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_create_default_wifi_sta();

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_start());

    ESP_LOGI(TAG, "WiFi STA iniciado");
}

void agregar_esp() {
    if(peer_agregado) return;
    esp_now_peer_info_t peer = {};
    memcpy(peer.peer_addr, mac_peer, 6);
    peer.channel = 0;
    peer.encrypt = false;

    esp_err_t result = esp_now_add_peer(&peer);
    if(result == ESP_OK || result == ESP_ERR_ESPNOW_EXIST) peer_agregado = true;
}

void on_data_sent(const uint8_t *mac_addr, esp_now_send_status_t status) {}

void on_data_recv(const esp_now_recv_info_t *info, const uint8_t *incomingData, int len) {
    memcpy(ultimo_mensaje, incomingData, len);
    ultimo_mensaje[len] = '\0';
    ESP_LOGI(TAG, "Mensaje recibido del maestro: %s", ultimo_mensaje);

    // Obtenemos la MAC del emisor
    const uint8_t *mac = info->src_addr;

    // Solo procesar mensajes válidos ("trafico" o "normal")
    if (strcmp(ultimo_mensaje, "trafico") == 0) {
        deteccion_remota = true;
        coneccion = true;
        xSemaphoreGive(sem_mensaje_nuevo);
        ESP_LOGI(TAG, "Estado remoto: TRÁFICO");
    } 
    else if (strcmp(ultimo_mensaje, "normal") == 0) {
        deteccion_remota = false;
        coneccion = true;
        xSemaphoreGive(sem_mensaje_nuevo);
        ESP_LOGI(TAG, "Estado remoto: NORMAL");
    } 
    else {
        // Ignorar cualquier otro mensaje (por ejemplo, ACKs u otros)
        //ESP_LOGW(TAG, "Mensaje ignorado (no es trafico ni normal): %s", ultimo_mensaje);
    }
}


void init_espnow(void) {
    esp_err_t ret = esp_now_init();
    if(ret != ESP_OK) return;
    esp_now_register_send_cb(on_data_sent);
    esp_now_register_recv_cb(on_data_recv);
}

// ==================== CONTROL SEMÁFORO ====================
void control_semaforo( int color) {
    switch(color) {
        case 0:
            gpio_set_direction(semaforo_uno.verde, GPIO_MODE_OUTPUT);
            gpio_set_direction(semaforo_uno.amarillo, GPIO_MODE_OUTPUT);
            gpio_set_direction(semaforo_uno.rojo, GPIO_MODE_OUTPUT);
            gpio_set_level(semaforo_uno.verde, 0);
            gpio_set_level(semaforo_uno.amarillo, 0);
            gpio_set_level(semaforo_uno.rojo, 0);
            break;
        case 1:
            gpio_set_level(semaforo_uno.verde,1);
            gpio_set_level(semaforo_uno.amarillo,0);
            gpio_set_level(semaforo_uno.rojo,0);
            break;
        case 2:
            gpio_set_level(semaforo_uno.verde,0);
            gpio_set_level(semaforo_uno.amarillo,1);
            gpio_set_level(semaforo_uno.rojo,0);
            break;
        case 3:
            gpio_set_level(semaforo_uno.verde,0);
            gpio_set_level(semaforo_uno.amarillo,0);
            gpio_set_level(semaforo_uno.rojo,1);
            break;
    }
}


// ==================== COMUNICACIÓN ====================
void enviar_mensaje(const char *mensaje) {
    esp_err_t resultado = esp_now_send(mac_peer, (uint8_t *)mensaje, strlen(mensaje));
    if (resultado == ESP_OK) {
        //printf("[ENVIADO] Mensaje enviado: %s\n", mensaje);
    } else {
        //printf("[ERROR] No se pudo enviar el mensaje: %s (Error %d)\n", mensaje, resultado);
    }
}

estado_t estado_actual = ESTADO_NORMAL;

gptimer_handle_t timer_semaforo = NULL;
gptimer_handle_t timer_extremos=NULL;
gptimer_handle_t timer_delay=NULL;
int fase = 1;

// --- Nuevas banderas (ponerlas en la sección de variables globales) ---
static bool timer_semaforo_en_marcha = false;
static bool timer_extremos_en_marcha = false;
static bool timer_delay_en_marcha = false;

static bool tiempo_verde = false;
static bool tiempo_amarillo = false;
static bool tiempo_rojo = false;

// Tiempos
const int TIEMPO_VERDE = 20;
const int TIEMPO_AMARILLO = 1;
const int TIEMPO_ROJO = 23;
const int TIEMPO_MAXIMO=40;
const int TIEMPO_MINIMO=10;
const int TIEMPO_DELAY=5;


// ==================== CALLBACKS - USAR SOLO CALLBACK_1 ====================
static bool callback_1(gptimer_handle_t timer, const gptimer_alarm_event_data_t *edata, void *user_ctx){
    gptimer_stop(timer);
    timer_semaforo_en_marcha = false;
    tiempo_1 = true;
    return false;
}

static bool callback_2(gptimer_handle_t timer, const gptimer_alarm_event_data_t *edata, void *user_ctx) {
    gptimer_stop(timer);
    timer_extremos_en_marcha = false;
    tiempo_2 = true;
    return false;
}

static bool callback_3(gptimer_handle_t timer, const gptimer_alarm_event_data_t *edata, void *user_ctx) {
    gptimer_stop(timer);
    timer_delay_en_marcha = false;
    tiempo_3 = true;
    return false;
}
void mostrar_estado(){
    if(coneccion){
        printf("conectado\n");
    }else{
        printf("desconectado\n");
    }
}
// ==================== TAREA SEMÁFORO MODIFICADA ====================
void tarea_semaforo(void *pvParameters) {
    typedef enum {
        ESTADO_VERDE,
        ESTADO_AMARILLO,
        ESTADO_ROJO
    } estado_luz_t;
    
    typedef enum {
        PRIORIDAD_FASE_VERDE,
        PRIORIDAD_FASE_AMARILLO_TRANSITORIO,
        PRIORIDAD_FASE_ROJO
    } fase_prioridad_t;
    
    estado_t estado_sistema = SIN_CONEXION;
    estado_luz_t estado_luz = ESTADO_VERDE;
    fase_prioridad_t fase_prioridad = PRIORIDAD_FASE_VERDE;
    gptimer_handle_t timer_semaforo;
    bool amarillo_parpadeando = false;
    
    // Variables para manejo del delay de salida
    bool en_delay_salida = false;
    uint32_t contador_delay = 0;
    const uint32_t DELAY_SALIDA_MS = 5000; // 5 segundos
    const uint32_t CICLO_MS = 100;
    
    // Configurar el timer del semáforo
    configurar_tiempo(&timer_semaforo, TIEMPO_VERDE, callback_1);
    
    // Inicializar semáforo apagado
    control_semaforo(0);
    
    printf("✅ Tarea semáforo iniciada\n");
    
    while(1) {
        // ==================== DETERMINAR CONDICIONES ACTUALES ====================
        bool condicion_prioridad1 = (coneccion && deteccion_local && !deteccion_remota);
        bool condicion_prioridad2 = (coneccion && !deteccion_local && deteccion_remota);
        bool condicion_normal = (coneccion && ((!deteccion_local && !deteccion_remota) || 
                                                (deteccion_local && deteccion_remota)));
        
        // ==================== MANEJO DEL DELAY DE SALIDA ====================
        if (estado_sistema == PRIORIDAD1 || estado_sistema == PRIORIDAD2) {
            // Desconexión = salida inmediata, sin delay
            if (!coneccion) {
                if (en_delay_salida) {
                    printf("⚠️  Desconexión detectada durante delay, cancelando delay\n");
                    en_delay_salida = false;
                    contador_delay = 0;
                }
                // Forzar cambio inmediato a SIN_CONEXION
                printf("🔴 Desconexión detectada en prioridad, cambiando a SIN_CONEXION\n");
                estado_sistema = SIN_CONEXION;
                
                // Iniciar parpadeo inmediatamente
                printf("🟡 Iniciando parpadeo amarillo por desconexión\n");
                amarillo_parpadeando = true;
                control_semaforo(2);
                tiempo_1 = false;
                
                if (timer_semaforo_en_marcha) {
                    gptimer_stop(timer_semaforo);
                }
                configurar_alarma(timer_semaforo, 1);
                gptimer_set_raw_count(timer_semaforo, 0);
                gptimer_start(timer_semaforo);
                timer_semaforo_en_marcha = true;
            } else {
                // Conexión activa, verificar condiciones de prioridad
                bool condicion_actual_cumplida = (estado_sistema == PRIORIDAD1) ? condicion_prioridad1 : condicion_prioridad2;
                
                if (!condicion_actual_cumplida) {
                    // Las condiciones dejaron de cumplirse
                    if (!en_delay_salida) {
                        // Iniciar el contador de delay
                        printf("⏱️  Condiciones de %s no se cumplen, iniciando delay de salida (%lums)\n",
                               (estado_sistema == PRIORIDAD1) ? "PRIORIDAD1" : "PRIORIDAD2",
                               (unsigned long)DELAY_SALIDA_MS);
                        en_delay_salida = true;
                        contador_delay = 0;
                    } else {
                        // Incrementar contador
                        contador_delay += CICLO_MS;
                        
                        if (contador_delay >= DELAY_SALIDA_MS) {
                            // Delay cumplido, cambiar de estado
                            printf("✅ Delay de salida cumplido, saliendo de prioridad\n");
                            
                            // Guardar fase actual antes de salir
                            fase_prioridad_t fase_al_salir = fase_prioridad;
                            
                            en_delay_salida = false;
                            contador_delay = 0;
                            
                            // Cambiar al estado normal
                            estado_t estado_saliente = estado_sistema;
                            estado_sistema = ESTADO_NORMAL;
                            
                            // Ajustar el estado de luz según de dónde venimos
                            if (estado_saliente == PRIORIDAD1) {
                                if (fase_al_salir == PRIORIDAD_FASE_VERDE || fase_al_salir == PRIORIDAD_FASE_AMARILLO_TRANSITORIO) {
                                    // Estaba en verde o en amarillo transitorio → pasar a amarillo
                                    printf("🟡 Saliendo de PRIORIDAD1 (estaba en verde/amarillo) → pasando a AMARILLO\n");
                                    estado_luz = ESTADO_AMARILLO;
                                    control_semaforo(2);
                                    
                                    if (timer_semaforo_en_marcha) {
                                        gptimer_stop(timer_semaforo);
                                    }
                                    
                                    tiempo_1 = false;
                                    configurar_alarma(timer_semaforo, TIEMPO_AMARILLO);
                                    gptimer_set_raw_count(timer_semaforo, 0);
                                    gptimer_start(timer_semaforo);
                                    timer_semaforo_en_marcha = true;
                                } else {
                                    // Estaba en rojo → pasar a verde
                                    printf("🟢 Saliendo de PRIORIDAD1 (estaba en rojo) → pasando a VERDE\n");
                                    estado_luz = ESTADO_VERDE;
                                    control_semaforo(1);
                                    
                                    if (timer_semaforo_en_marcha) {
                                        gptimer_stop(timer_semaforo);
                                    }
                                    
                                    tiempo_1 = false;
                                    configurar_alarma(timer_semaforo, TIEMPO_VERDE);
                                    gptimer_set_raw_count(timer_semaforo, 0);
                                    gptimer_start(timer_semaforo);
                                    timer_semaforo_en_marcha = true;
                                }
                            } else if (estado_saliente == PRIORIDAD2) {
                                if (fase_al_salir == PRIORIDAD_FASE_ROJO) {
                                    // Estaba en rojo → pasar a verde
                                    printf("🟢 Saliendo de PRIORIDAD2 (estaba en rojo) → pasando a VERDE\n");
                                    estado_luz = ESTADO_VERDE;
                                    control_semaforo(1);
                                    
                                    if (timer_semaforo_en_marcha) {
                                        gptimer_stop(timer_semaforo);
                                    }
                                    
                                    tiempo_1 = false;
                                    configurar_alarma(timer_semaforo, TIEMPO_VERDE);
                                    gptimer_set_raw_count(timer_semaforo, 0);
                                    gptimer_start(timer_semaforo);
                                    timer_semaforo_en_marcha = true;
                                } else {
                                    // Estaba en verde o amarillo transitorio → pasar a amarillo
                                    printf("🟡 Saliendo de PRIORIDAD2 (estaba en verde/amarillo) → pasando a AMARILLO\n");
                                    estado_luz = ESTADO_AMARILLO;
                                    control_semaforo(2);
                                    
                                    if (timer_semaforo_en_marcha) {
                                        gptimer_stop(timer_semaforo);
                                    }
                                    
                                    tiempo_1 = false;
                                    configurar_alarma(timer_semaforo, TIEMPO_AMARILLO);
                                    gptimer_set_raw_count(timer_semaforo, 0);
                                    gptimer_start(timer_semaforo);
                                    timer_semaforo_en_marcha = true;
                                }
                            }
                        }
                    }
                } else {
                    // Las condiciones volvieron a cumplirse, cancelar delay
                    if (en_delay_salida) {
                        printf("🔄 Condiciones vuelven a cumplirse, cancelando delay de salida\n");
                        en_delay_salida = false;
                        contador_delay = 0;
                    }
                }
            }
        }
        
        // ==================== DETERMINAR ESTADO DEL SISTEMA ====================
        estado_t estado_anterior = estado_sistema;
        
        // Solo cambiar estado si NO estamos en delay de salida
        if (!en_delay_salida) {
            if (!coneccion) {
                estado_sistema = SIN_CONEXION;
            } else if (deteccion_local && !deteccion_remota) {
                estado_sistema = PRIORIDAD1;
            } else if (!deteccion_local && deteccion_remota) {
                estado_sistema = PRIORIDAD2;
            } else {
                estado_sistema = ESTADO_NORMAL;
            }
        }
        
        // Detectar cambio de estado
        if (estado_anterior != estado_sistema) {
            printf("🔄 Cambio de estado: ");
            switch(estado_sistema) {
                case SIN_CONEXION:
                    printf("SIN_CONEXION\n");
                    break;
                case ESTADO_NORMAL:
                    printf("ESTADO_NORMAL\n");
                    break;
                case PRIORIDAD1:
                    printf("PRIORIDAD1 (detección local)\n");
                    break;
                case PRIORIDAD2:
                    printf("PRIORIDAD2 (detección remota)\n");
                    break;
            }
        }
        
        // ==================== MANEJAR SEGÚN ESTADO ====================
        switch(estado_sistema) {
            case SIN_CONEXION:
                // Iniciar parpadeo si viene de otro estado
                if (estado_anterior != SIN_CONEXION) {
                    printf("🟡 Iniciando parpadeo amarillo\n");
                    amarillo_parpadeando = true;
                    control_semaforo(2);
                    tiempo_1 = false;
                    
                    if (timer_semaforo_en_marcha) {
                        gptimer_stop(timer_semaforo);
                    }
                    configurar_alarma(timer_semaforo, 1);
                    gptimer_set_raw_count(timer_semaforo, 0);
                    gptimer_start(timer_semaforo);
                    timer_semaforo_en_marcha = true;
                }
                
                // Manejar parpadeo
                if (tiempo_1) {
                    tiempo_1 = false;
                    
                    if (amarillo_parpadeando) {
                        control_semaforo(0);
                        amarillo_parpadeando = false;
                    } else {
                        control_semaforo(2);
                        amarillo_parpadeando = true;
                    }
                    
                    gptimer_stop(timer_semaforo);
                    configurar_alarma(timer_semaforo, 1);
                    gptimer_set_raw_count(timer_semaforo, 0);
                    gptimer_start(timer_semaforo);
                }
                break;
            case ESTADO_NORMAL:
                    // Solo inicializar si viene de SIN_CONEXION
                    if (estado_anterior == SIN_CONEXION) {
                        printf("🔴 Iniciando en ROJO (modo normal)\n");  // Cambiado de VERDE a ROJO
                        estado_luz = ESTADO_ROJO;  // Cambiado
                        control_semaforo(3);  // Cambiado de 1 a 3
                        tiempo_1 = false;
                        
                        if (timer_semaforo_en_marcha) {
                            gptimer_stop(timer_semaforo);
                        }
                        
                        configurar_alarma(timer_semaforo, TIEMPO_ROJO);  // Cambiado de TIEMPO_VERDE
                        gptimer_set_raw_count(timer_semaforo, 0);
                        gptimer_start(timer_semaforo);
                        timer_semaforo_en_marcha = true;
                    }
                
                // Manejar transiciones
                if (tiempo_1) {
                    tiempo_1 = false;
                    
                    switch(estado_luz) {
                        case ESTADO_VERDE:
                            // Verde → Amarillo
                            printf("🟡 VERDE → AMARILLO\n");
                            estado_luz = ESTADO_AMARILLO;
                            control_semaforo(2);
                            
                            gptimer_stop(timer_semaforo);
                            configurar_alarma(timer_semaforo, TIEMPO_AMARILLO);
                            gptimer_set_raw_count(timer_semaforo, 0);
                            gptimer_start(timer_semaforo);
                            break;
                            
                        case ESTADO_AMARILLO:
                            // Amarillo → Rojo
                            printf("🔴 AMARILLO → ROJO\n");
                            estado_luz = ESTADO_ROJO;
                            control_semaforo(3);
                            
                            gptimer_stop(timer_semaforo);
                            configurar_alarma(timer_semaforo, TIEMPO_ROJO);
                            gptimer_set_raw_count(timer_semaforo, 0);
                            gptimer_start(timer_semaforo);
                            break;
                            
                        case ESTADO_ROJO:
                            // Rojo → Verde (directo)
                            printf("🟢 ROJO → VERDE\n");
                            estado_luz = ESTADO_VERDE;
                            control_semaforo(1);
                            
                            gptimer_stop(timer_semaforo);
                            configurar_alarma(timer_semaforo, TIEMPO_VERDE);
                            gptimer_set_raw_count(timer_semaforo, 0);
                            gptimer_start(timer_semaforo);
                            break;
                    }
                }
                break;
                
            case PRIORIDAD1:
                // Prioridad local con control de tiempos
                if (estado_anterior != PRIORIDAD1) {
                    printf("🟢 PRIORIDAD1: Iniciando fase VERDE (máx %ds)\n", TIEMPO_MAXIMO);
                    fase_prioridad = PRIORIDAD_FASE_VERDE;
                    
                    if (timer_semaforo_en_marcha) {
                        gptimer_stop(timer_semaforo);
                    }
                    
                    control_semaforo(1);
                    tiempo_1 = false;
                    
                    configurar_alarma(timer_semaforo, TIEMPO_MAXIMO);
                    gptimer_set_raw_count(timer_semaforo, 0);
                    gptimer_start(timer_semaforo);
                    timer_semaforo_en_marcha = true;
                }
                
                // Manejar fases de PRIORIDAD1
                if (tiempo_1) {
                    tiempo_1 = false;
                    
                    switch(fase_prioridad) {
                        case PRIORIDAD_FASE_VERDE:
                            // Terminó tiempo máximo en verde, pasar a amarillo
                            printf("🟡 PRIORIDAD1: Tiempo máximo alcanzado, pasando a AMARILLO transitorio\n");
                            fase_prioridad = PRIORIDAD_FASE_AMARILLO_TRANSITORIO;
                            estado_luz = ESTADO_AMARILLO;
                            control_semaforo(2);
                            
                            gptimer_stop(timer_semaforo);
                            configurar_alarma(timer_semaforo, TIEMPO_AMARILLO);
                            gptimer_set_raw_count(timer_semaforo, 0);
                            gptimer_start(timer_semaforo);
                            break;
                            
                        case PRIORIDAD_FASE_AMARILLO_TRANSITORIO:
                            // Terminó amarillo, pasar a rojo por tiempo mínimo
                            printf("🔴 PRIORIDAD1: Pasando a ROJO (mín %ds)\n", TIEMPO_MINIMO);
                            fase_prioridad = PRIORIDAD_FASE_ROJO;
                            estado_luz = ESTADO_ROJO;
                            control_semaforo(3);
                            
                            gptimer_stop(timer_semaforo);
                            configurar_alarma(timer_semaforo, TIEMPO_MINIMO);
                            gptimer_set_raw_count(timer_semaforo, 0);
                            gptimer_start(timer_semaforo);
                            break;
                            
                        case PRIORIDAD_FASE_ROJO:
                            // Terminó el tiempo mínimo en rojo, volver a verde
                            printf("🟢 PRIORIDAD1: Tiempo mínimo cumplido, volviendo a VERDE (máx %ds)\n", TIEMPO_MAXIMO);
                            fase_prioridad = PRIORIDAD_FASE_VERDE;
                            estado_luz = ESTADO_VERDE;
                            control_semaforo(1);
                            
                            gptimer_stop(timer_semaforo);
                            configurar_alarma(timer_semaforo, TIEMPO_MAXIMO);
                            gptimer_set_raw_count(timer_semaforo, 0);
                            gptimer_start(timer_semaforo);
                            break;
                            
                        default:
                            break;
                    }
                }
                break;
                
            case PRIORIDAD2:
                // Prioridad remota con control de tiempos
                if (estado_anterior != PRIORIDAD2) {
                    printf("🔴 PRIORIDAD2: Iniciando fase ROJO (máx %ds)\n", TIEMPO_MAXIMO);
                    fase_prioridad = PRIORIDAD_FASE_ROJO;
                    
                    if (timer_semaforo_en_marcha) {
                        gptimer_stop(timer_semaforo);
                    }
                    
                    control_semaforo(3);
                    tiempo_1 = false;
                    
                    configurar_alarma(timer_semaforo, TIEMPO_MAXIMO);
                    gptimer_set_raw_count(timer_semaforo, 0);
                    gptimer_start(timer_semaforo);
                    timer_semaforo_en_marcha = true;
                }
                
                // Manejar fases de PRIORIDAD2
                if (tiempo_1) {
                    tiempo_1 = false;
                    
                    switch(fase_prioridad) {
                        case PRIORIDAD_FASE_ROJO:
                            // Se acabó el tiempo máximo en rojo, pasar a verde (directo)
                            printf("🟢 PRIORIDAD2: Tiempo máximo alcanzado, pasando a VERDE (mín %ds)\n", TIEMPO_MINIMO);
                            fase_prioridad = PRIORIDAD_FASE_VERDE;
                            estado_luz = ESTADO_VERDE;
                            control_semaforo(1);
                            
                            gptimer_stop(timer_semaforo);
                            configurar_alarma(timer_semaforo, TIEMPO_MINIMO);
                            gptimer_set_raw_count(timer_semaforo, 0);
                            gptimer_start(timer_semaforo);
                            break;
                            
                        case PRIORIDAD_FASE_VERDE:
                            // Terminó el tiempo mínimo en verde, pasar a amarillo
                            printf("🟡 PRIORIDAD2: Tiempo mínimo cumplido, pasando a AMARILLO transitorio\n");
                            fase_prioridad = PRIORIDAD_FASE_AMARILLO_TRANSITORIO;
                            estado_luz = ESTADO_AMARILLO;
                            control_semaforo(2);
                            
                            gptimer_stop(timer_semaforo);
                            configurar_alarma(timer_semaforo, TIEMPO_AMARILLO);
                            gptimer_set_raw_count(timer_semaforo, 0);
                            gptimer_start(timer_semaforo);
                            break;
                            
                        case PRIORIDAD_FASE_AMARILLO_TRANSITORIO:
                            // Terminó amarillo, pasar a rojo por tiempo máximo
                            printf("🔴 PRIORIDAD2: Pasando a ROJO (máx %ds)\n", TIEMPO_MAXIMO);
                            fase_prioridad = PRIORIDAD_FASE_ROJO;
                            estado_luz = ESTADO_ROJO;
                            control_semaforo(3);
                            
                            gptimer_stop(timer_semaforo);
                            configurar_alarma(timer_semaforo, TIEMPO_MAXIMO);
                            gptimer_set_raw_count(timer_semaforo, 0);
                            gptimer_start(timer_semaforo);
                            break;
                            
                        default:
                            break;
                    }
                }
                break;
        }
        
        vTaskDelay(pdMS_TO_TICKS(CICLO_MS));
    }
}

bool detect_vehicle() {
    uint32_t distance;
    esp_err_t res = ultrasonic_measure_cm(&sensor_ultrasonic, 400, &distance);

    if (res == ESP_OK) {
        return distance < DETECTION_DISTANCE;  // por ejemplo
    } else {
        ESP_LOGE(TAG, "Error sensor: 0x%x", res);
        return false;
    }
}

static void init_oled(void)
{
    init_ssd1306();
    ESP_LOGI(TAG, "Display oled Inicializado");

    ssd1306_clear();
    ssd1306_print_str(0, 0, "SEMAFORO-A INIT", false);
    ssd1306_display();
}
void iniciar_ultrasonico(){
    esp_err_t ret = ultrasonic_init(&sensor_ultrasonic);
        if (ret != ESP_OK)
    {
        ESP_LOGE(TAG, "ERROR STARTING SENSOR ULTRASONIC");
    }

}

void tarea_comunicacion(void *pvParameters) {
    int contador_sin_actividad = 0;
    const int TIMEOUT_DESCONEXION = 10; // 10 iteraciones × 200ms = 2 segundos
    
    while (1) {
        // Intentar recibir mensaje con timeout MUY corto (solo para no bloquear)
        if (xSemaphoreTake(sem_mensaje_nuevo, pdMS_TO_TICKS(50)) == pdTRUE) {
            // ✅ Mensaje recibido - resetear contador
            contador_sin_actividad = 0;
            coneccion = true; // Asegurar que esté conectado
            
            ESP_LOGI(TAG, "Procesando mensaje: %s", ultimo_mensaje);

            if (deteccion_remota) {
                ESP_LOGI(TAG, "El maestro detecta tráfico");
            } else {
                ESP_LOGI(TAG, "El maestro está en estado normal");
            }

            // 🔁 Responder al maestro
            const char *respuesta = deteccion_local ? "trafico" : "normal";
            esp_now_send(mac_peer, (uint8_t *)respuesta, strlen(respuesta));
            
        } else {
            // ❌ No se recibió mensaje - incrementar contador
            contador_sin_actividad++;
            
            // Detectar desconexión después de TIMEOUT_DESCONEXION iteraciones
            if (contador_sin_actividad >= TIMEOUT_DESCONEXION) {
                if (coneccion) { // Solo mostrar una vez
                    ESP_LOGW(TAG, "⚠️  SIN COMUNICACIÓN - Desconectado");
                }
                coneccion = false;
                deteccion_remota = false;
            }
        }

        vTaskDelay(pdMS_TO_TICKS(200)); // Verificar cada 200ms
    }
}

uint32_t distancia = 0;
void tarea_ultrasonico(void *pvParameters) {
    while (1) {
        esp_err_t res = ultrasonic_measure_cm(&sensor_ultrasonic, 400, &distancia);

        if (res == ESP_OK) {
            deteccion_local = (distancia < DETECTION_DISTANCE);
            //ESP_LOGI(TAG, "Distancia: %lu cm (%s)", distancia,
              //       deteccion_local ? "TRAFICO" : "NORMAL");
        } else if (res == ESP_ERR_TIMEOUT) {
            ESP_LOGW(TAG, "Timeout: sin eco");
        } else {
            ESP_LOGE(TAG, "Error sensor: %s", esp_err_to_name(res));
        }

        vTaskDelay(pdMS_TO_TICKS(200)); // tiempo entre mediciones
    }
}
void tarea_display(void *pvParameters)
{
    // Inicializa la pantalla
    init_ssd1306();

    while (1)
    {
        ssd1306_clear();

        // Encabezado
        ssd1306_print_str(10, 8, "ESTADO DE TRAFICO", false);

        // Estado local
        if (deteccion_local)
            ssd1306_print_str(10, 24, "LOCAL:   TRAFICO", true);
        else
            ssd1306_print_str(10, 24, "LOCAL:   NORMAL", false);

        // Estado remoto
        if (deteccion_remota)
            ssd1306_print_str(10, 40, "REMOTO:  TRAFICO", true);
        else
            ssd1306_print_str(10, 40, "REMOTO:  NORMAL", false);

        ssd1306_display();
        vTaskDelay(pdMS_TO_TICKS(500)); // Actualiza cada 0.5s
    }
}
// ==================== APP MAIN ====================
void app_main(void){
    ESP_LOGI(TAG,"Iniciando sistema semafórico inteligente");
    sem_mensaje_nuevo = xSemaphoreCreateBinary();
    init_wifi();
    init_espnow();
    agregar_esp();
    init_oled();
    esp_err_t ret = ultrasonic_init(&sensor_ultrasonic);
        if (ret != ESP_OK)
    {
        ESP_LOGE(TAG, "ERROR STARTING SENSOR ULTRASONIC");
    }

    control_semaforo(0);
    xTaskCreate(tarea_ultrasonico,"Semaforo",4096,NULL,5,NULL);
    xTaskCreate(tarea_comunicacion,"Comunicacion",4096,NULL,5,NULL);
    xTaskCreate(tarea_display, "Display", 4096, NULL, 4, NULL);
    xTaskCreate(tarea_semaforo,"Semaforo",4096,NULL,5,NULL);

    ESP_LOGI(TAG,"✓ Sistema inicializado correctamente");
    /*while(1){
        if(detect_vehicle()){
            printf("vehiculo detectado\n");
        }else{
            printf("sin trafico\n");
        }
        vTaskDelay(pdMS_TO_TICKS(500));
    }*/
}
